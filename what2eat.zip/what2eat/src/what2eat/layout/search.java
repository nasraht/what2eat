package what2eat.layout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class search extends Activity {

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
	}
	
	public void onClick(View v){
    	switch(v.getId()){
    	
    	case R.id.home_button:
			Intent myIntent1 = new Intent(v.getContext(), main_menu.class);
            startActivity(myIntent1);
        break;
        
		case R.id.search_button:
			Intent myIntent2 = new Intent(v.getContext(), search.class);
            startActivity(myIntent2);
        break;
        
    	}
   }
}
