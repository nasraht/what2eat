package what2eat.layout;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;

public class tharsanJson extends Activity {
	
    /** Called when the activity is first created. */
	TextView check;
	@Override
    public void onCreate(Bundle savedInstanceState) {
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build();
		StrictMode.setThreadPolicy(policy);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.httpex);
        check = (TextView) findViewById(R.id.tvhttp);
        GetMethodEx test = new GetMethodEx();
        String returned;
        String parsed;
        
        try{
        	returned = test.getInternetData();
        	parsed = test.parse_Data(returned);
            check.setText(parsed);
                        
        }catch(Exception e){
        	check.setText("exception");
        	e.printStackTrace();
        }
	
	}
}