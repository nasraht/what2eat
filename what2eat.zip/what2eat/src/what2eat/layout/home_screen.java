package what2eat.layout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;

public class home_screen extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build();
		StrictMode.setThreadPolicy(policy);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro);
        
       Handler handler = new Handler();
        handler.postDelayed(new Runnable(){
           public void run() {
              startActivity(new Intent(getApplicationContext(), main_menu.class));
           }
        }, 5);
    }
}