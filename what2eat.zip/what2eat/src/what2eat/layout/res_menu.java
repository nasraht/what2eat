package what2eat.layout;

import what2eat.layout.DtopActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class res_menu extends Activity {

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.res_menu);
        
        ListView listView = (ListView) findViewById(R.id.name_resteraunts);
        String[] names = new String[] {"Tim Horton's","Rex's Den","La Prep","Market Place"};
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
        		android.R.layout.simple_list_item_1, android.R.id.text1, names);
        
        listView.setAdapter(adapter);
        
        listView.setOnItemClickListener(new OnItemClickListener() {
        	
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        		switch(position){
        			case 0:
        				DtopActivity.sendAccelerationData("Tim Hortons");
        				Intent myIntent = new Intent(view.getContext(), tharsanJson.class);
                        startActivity(myIntent);
                        //DtopActivity.sendAccelerationData("Tim Hortons");
                        
                    break;
        			case 1:
        				Intent myIntent2 = new Intent(view.getContext(), res_menu.class);
                        startActivity(myIntent2);
                    break;
        			case 2:
        				Intent myIntent3 = new Intent(view.getContext(), recomendation.class);
                        startActivity(myIntent3);
                    break;
        		}
        	}
        });
	}
	
	public void onClick(View v){
    	switch(v.getId()){
    	
    	case R.id.home_button:
			Intent myIntent1 = new Intent(v.getContext(), main_menu.class);
            startActivity(myIntent1);
        break;
        
		case R.id.search_button:
			Intent myIntent2 = new Intent(v.getContext(), search.class);
            startActivity(myIntent2);
        break;
    	}
    }
}
