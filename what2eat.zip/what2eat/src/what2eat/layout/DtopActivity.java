package what2eat.layout;

import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;


import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;

public class DtopActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().detectAll().penaltyLog().build();
		StrictMode.setThreadPolicy(policy);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //sendAccelerationData("hello");        
    }
    
   
private static void sendData(ArrayList<NameValuePair> data)
{
     // 1) Connect via HTTP. 2) Encode data. 3) Send data.
    try
    {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new      
        HttpPost("http://142.1.84.150/mynewsite/dtopprint.php");
        httppost.setEntity(new UrlEncodedFormEntity(data));
        HttpResponse response = httpclient.execute(httppost);
        Log.i("postData", response.getStatusLine().toString());
            //Could do something better with response.
    }
    catch(Exception e)
    {
        Log.e("log_tag", "Error:  "+e.toString());
    }  
}

static void sendAccelerationData(String restname)
{
    //fileName = "AddAccelerationData.php";

    //Add data to be send.
    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
    nameValuePairs.add(new BasicNameValuePair("name", restname));
    

    sendData(nameValuePairs);
}

}