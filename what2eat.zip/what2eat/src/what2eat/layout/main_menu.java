package what2eat.layout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class main_menu extends Activity {
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ListView listView = (ListView) findViewById(R.id.menu_options);
        String[] options = new String[] {"Specials","Resteraunts","Recommendations"};
        
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
        		android.R.layout.simple_list_item_1, android.R.id.text1, options);
        
        listView.setAdapter(adapter);
        
        listView.setOnItemClickListener(new OnItemClickListener() {
        	
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        		switch(position){
        			case 0:
        				Intent myIntent1 = new Intent(view.getContext(), special.class);
                        startActivity(myIntent1);
                    break;
        			case 1:
        				Intent myIntent2 = new Intent(view.getContext(), res_menu.class);
                        startActivity(myIntent2);
                    break;
        			case 2:
        				Intent myIntent3 = new Intent(view.getContext(), recomendation.class);
                        startActivity(myIntent3);
                    break;
        		}
        	}
        });
        
    }
 
    public void onClick(View v){
    	switch(v.getId()){
    	
    		case R.id.home_button:
    			Intent myIntent1 = new Intent(v.getContext(), main_menu.class);
                startActivity(myIntent1);
            break;
            
    		case R.id.search_button:
    			Intent myIntent2 = new Intent(v.getContext(), search.class);
                startActivity(myIntent2);
            break;
    	}
    }
}
