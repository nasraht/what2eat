/** Automatically generated file. DO NOT MODIFY */
package what2eat.layout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}